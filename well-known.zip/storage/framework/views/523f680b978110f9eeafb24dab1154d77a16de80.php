<?php
if (Auth('admin')->User()->dashboard_style == "light") {
    $text = "dark";
} else {
    $text = "light";
}
?>

    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('admin.topmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-panel bg-<?php echo e(Auth('admin')->User()->dashboard_style); ?>">
            <div class="content">
                <div class="page-inner">
                    <div class="mt-2 mb-4">
                    
                    </div>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.danger-alert','data' => []]); ?>
<?php $component->withName('danger-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.success-alert','data' => []]); ?>
<?php $component->withName('success-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        
                    <div class="mb-5 row">
                        <div class="col-12 p-4 card shadow bg-<?php echo e(Auth('admin')->User()->dashboard_style); ?>">
                            <h1 class="title1 text-<?php echo e($text); ?>">About Remedy </h1>
                            <p class="title1 text-<?php echo e($text); ?>"> Contact Us Today For customization and more designs and product </p>
                            <div>
							<p> For Help More scripts, designs and customization contact us below </p>
							
							<p> We have all kinds of script for your online work.</p>
							<ol>
							    <li> Banking script</li>
							    <li> Investment script (Hyip) (Bitcoin investment websites)</li>
							    
							    <li>Military application for military hustle</li>
							    <li> Courier website etc.</li>
							</ol>
                                <small class="text-info"></small>
							</div>
                            <div class="mt-4">
                                <a href="https://t.me/+VRumJJSKKGdjM2I0" target="_blank" class="btn btn-primary"> Join Our Telegram channel</a>
                            </div>
                            
                            
                            <div class="mt-4">
                                <h1> Email us today</h1>
                               <h2> remedytechservces@gmail.com</h2>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>   
            </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/quicvzsn/onlinecrptotradingplatform.com/resources/views/admin/about.blade.php ENDPATH**/ ?>