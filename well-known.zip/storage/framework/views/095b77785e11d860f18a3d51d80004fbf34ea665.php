<?php echo e($slot); ?>

<?php /**PATH /home/smarjcxc/hyip.smartexpertfx.com/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>